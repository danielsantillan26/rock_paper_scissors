/*
Name: Daniel Santillan
Class: AP CS A
Date: 11/29/2023
Program Description: Rock Paper Scissors

This class runs the entire Rock Paper Scissors game.

Most code comments will be to the far right of the code segments
(~ column 173) for the sake of neatness.

*/





// IMPORTS
import java.util.Scanner;

public class RockPaperScissors {
   
   
   // FIELDS
   Scanner kb;
   
   private int[] playerWins;                                                                                                                                                // The player wins and names arrays helps me create a player database for statistics.
   private String[] playerNames;
   

   
   

   // CONSTRUCTOR
   public RockPaperScissors() {
      kb = new Scanner(System.in);                                                                                                                                          // The implementation of the Scanner object in the constructor relieves me of creating new objects all the time.
      playerWins = new int[100];                                                                                                                                            // There can be at most 100 different players in the database each run.
      playerNames = new String[100];
   }
   
   
   
   
   // The run() method runs the main menu, which lets players access various aspects of the game.
   public void run() {
      System.out.println("Welcome to Rock Paper Scissors!");
      System.out.println("Proceed by typing the number of the option you wish to proceed to, then press enter.");
      System.out.println("[1]: Human Versus Human");
      System.out.println("[2]: Human Versus Computer");                                                                                                                     // Users select the number of the option of their choice.
      System.out.println("[3]: Statistics");
      System.out.println("[4]: Quit\n");                                                                                                                                    // The \n at the end is a personal spacing style choice, FYI (You'll see this a few times).
      
      
      int menuChoice = 0;
      
      while (menuChoice < 1 || menuChoice > 4) {                                                                                                                            // All of my error handling is like this.
         try {                                                                                                                                                              // It tries to get correct input if the input either:
            menuChoice = kb.nextInt();
            kb.nextLine();
            
            if (menuChoice > 4) {
               System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");                                                 // - is out-of-range
            }
            
         } catch (Exception e) {
            System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");                                                    // - or results in an InputMismatchException.
            kb.nextLine();                                                                                                                                                  // The nextLine() prevents infinte spam of the "Invalid Input" message.
         }
      }
      
      
      switch (menuChoice) {
         case 1:
            runHumanVersusHuman();                                                                                                                                          // Determining which methods to run according to user selection.
            break;
            
         case 2:
            runHumanVersusComputer();
            break;
            
         case 3:
            displayStatistics();
            break;
            
         case 4:
            System.out.println("\nThanks for playing Rock Paper Scissors!");
            System.out.println("Play again soon.");
            System.exit(0);                                                                                                                                                 // System.exit(0); ends the run.
            break;
      }
   }
   
   
   
   
   
   // The runHumanVersusHuman() method runs the Human Versus Human mode menu, allowing users to play Human Versus Human.
   // It's all the same as the run() method.
   public void runHumanVersusHuman() {
      System.out.println("\nWelcome to Human Versus Human!");
      System.out.println("Proceed by typing the number of the option you wish to proceed to, then press enter.");
      System.out.println("[1]: Play Human Versus Human");
      System.out.println("[2]: View Instructions");
      System.out.println("[3]: Return to Main Menu\n");
      
      
      int menuChoice = 0;
      
      while (menuChoice < 1 || menuChoice > 3) {                                                                                                                            // Error handling for InputMismatchException and "out-of-bounds" inputs                                                                                                                    
         try {                                                                                                                                                          
            menuChoice = kb.nextInt();
            kb.nextLine();
            
            if (menuChoice > 3) {
               System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");                                                 
            }
            
         } catch (Exception e) {
            System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");                                                    
            kb.nextLine();                                                                                                                                                  
         }
      }
      
      
      switch (menuChoice) {                                                                                                                                                 // The switch statement determines the subsequent action.
         case 1:
            playHumanVersusHuman();
            break;
            
         case 2:
            displayHumanVersusHumanInstructions();
            break;
            
         case 3:
            run();                                                                                                                                                          // Re-accessing run() returns a user to the main menu.
            break;
      }
      
   }
   
   
   
   
   
   // The playHumanVersusHuman() method runs the Human Versus Human edition of Rock Paper Scissors.
   public void playHumanVersusHuman() {
      System.out.println("\nLet's Play!");
      System.out.println("Player One: Select a character.\n");                                                                                                              // This asks player 1 to select a character.
      System.out.println("Proceed by typing the number of the option you wish to proceed to, then press enter.\n");
      System.out.println("[0]: Create a New Character");
      
      int playerSelectionLimit = 0;                                                                                                                                         // The playerSelectionLimit is a limit for correct input.
      
      for (int i = 1; i < 100; i++) {
         if (getPlayerName(i) != null) {
            System.out.println("[" + i + "]: " + getPlayerName(i));
            playerSelectionLimit = i;                                                                                                                                       // That limit depends on the amount of existing players (which are printed) in the database.
         }
      }
      
      System.out.println("");
      
      int playerOnePlayerChoice = -1;                                                                                                                                       // playerOnePlayerChoice holds the first player's player selection.
      int playerOneIndex = -1;                                                                                                                                              // playerOneIndex holds the first player's index in the database, which is important for statistics.
      
      while (playerOnePlayerChoice < 0 || playerOnePlayerChoice > playerSelectionLimit) {                                                                                   // Error handling for InputMismatchException and "out-of-bounds" inputs
         try {
         
            playerOnePlayerChoice = kb.nextInt();
            kb.nextLine();
            
            if (playerOnePlayerChoice > playerSelectionLimit) {
               System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
            }
         
         } catch (Exception e) {
            System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
            kb.nextLine();
         }
      }
      
      String playerOneName = "";                                                                                                                                            // playerOneName holds the first player's name for easy access.
      
      if (playerOnePlayerChoice == 0) {                                                                                                                                     // If the user creates a new character,
         System.out.println("\nChoose a name!");
         playerOneName = kb.nextLine();                                                                                                                                     // a name is chosen
         
         for (int i = 1; i < 100; i++) {                                                                                                                                    // and the name/user is added to the next vacant space in the database.
            if (getPlayerName(i) == null) {
               setPlayerName(i, playerOneName);
               playerOneIndex = i;                                                                                                                                          // The index is set according to the user's location in the database.
               break;
            }
         }
      } else {
         playerOneName = getPlayerName(playerOnePlayerChoice);                                                                                                              // Otherwise, collect the information from the user's desired player choice that already exists in the database.
         playerOneIndex = playerOnePlayerChoice;
      }
      
      System.out.println("\nWelcome to the game, " + playerOneName + "!\n");
      
      System.out.println("Player Two: Select a Character.\n");                                                                                                              // It's the same process for player two.
      System.out.println("Proceed by typing the number of the option you wish to proceed to, then press enter.\n");
      System.out.println("[0]: Create a New Character");
   
      for (int i = 1; i < 100; i++) {
         if (getPlayerName(i) != null && !(getPlayerName(i).equals(playerOneName))) {                                                                                       // !(getPlayerName(i).equals(playerOneName) ensures that player one's user does not appear on the list of accepted options.
            System.out.println("[" + i + "]: " + getPlayerName(i));
         }
      }
      
      System.out.println("");
      
      int playerTwoPlayerChoice = -1;
      int playerTwoIndex = -1;
      
      while (playerTwoPlayerChoice < 0 || playerTwoPlayerChoice > playerSelectionLimit || (playerTwoPlayerChoice == playerOnePlayerChoice && playerOnePlayerChoice != 0)) { // This extra potential condition for the while loop ensures that player one's user is not an accepted option for player two.
         try {                                                                                                                                                              
         
            playerTwoPlayerChoice = kb.nextInt();
            kb.nextLine();
            
            if (playerTwoPlayerChoice > playerSelectionLimit || (playerTwoPlayerChoice == playerOnePlayerChoice && playerOnePlayerChoice != 0)) {
               System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
            }
         
         } catch (Exception e) {
            System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
            kb.nextLine();
         }
      }
      
      String playerTwoName = "";
      
      if (playerTwoPlayerChoice == 0) {
         System.out.println("\nChoose a name!");
         playerTwoName = kb.nextLine();
         
         for (int i = 1; i < 100; i++) {
            if (getPlayerName(i) == null) {
               setPlayerName(i, playerTwoName);
               playerTwoIndex = i;
               break;
            }
         }
      } else {
         playerTwoName = getPlayerName(playerTwoPlayerChoice);
         playerTwoIndex = playerTwoPlayerChoice;
      }
      
      System.out.println("\nWelcome to the game, " + playerTwoName + "!\n");
      
      
      
      
      
      int playerOneWins = 0;                                                                                                                                                // The win variables hold the amount of round wins each user has.
      int playerTwoWins = 0;
      
      while (playerOneWins < 2 && playerTwoWins < 2) {                                                                                                                      // The game continues as long as each user hasn't yet won two rounds.
         System.out.println("\n" + playerOneName + ", choose an option.");                                                                                                  // Player one chooses a numerical option that represents rock, paper, or scissors.
         System.out.println("Type in 0 for Rock, 1 for Paper, and 2 for Scissors. Press enter when you have confirmed your choice.");
         System.out.println("Rock, Paper, Scissors, Shoot!\n");
      
         int playerOneChoice = -1;                                                                                                                                          // Options are held in the "player__Choice" variables.
      
         while (playerOneChoice < 0 || playerOneChoice > 2) {                                                                                                               // Error handling for InputMismatchException and "out-of-bounds" input
            try {
            
               playerOneChoice = kb.nextInt();
               kb.nextLine();
            
               if (playerOneChoice > 2) {
                  System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
               }
            
            } catch (Exception e) {
               System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
               kb.nextLine();
            }
         }
      
         System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");  // Yes, that is me trying to hide the user choices with new line spams.
         System.out.println(playerTwoName + ", choose an option.");                                                                                                         // Player two chooses an option.
         System.out.println("Type in 0 for Rock, 1 for Paper, and 2 for Scissors. Press enter when you have confirmed your choice.");
         System.out.println("Rock, Paper, Scissors, Shoot!\n");
      
         int playerTwoChoice = -1;
      
         while (playerTwoChoice < 0 || playerTwoChoice > 2) {                                                                                                               // It's the same process compared to player one.
            try {
            
               playerTwoChoice = kb.nextInt();
               kb.nextLine();
            
               if (playerTwoChoice > 2) {
                  System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
               }
            
            } catch (Exception e) {
               System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
               kb.nextLine();
            }
         }
      
         String playerOneChoiceString = "";                                                                                                                                 // These "ChoiceString" variables hold the user's selection as a string.
         String playerTwoChoiceString = "";                                                                                                                                 // This is important for the end-of-round text to tell users what each person chose.
      
         if (playerOneChoice == 0) {                                                                                                                                        // Each number corresponds with either rock, paper, or scissors.
            playerOneChoiceString = "rock";
         } else if (playerOneChoice == 1) {
            playerOneChoiceString = "paper";
         } else {
            playerOneChoiceString = "scissors";
         }
      
         if (playerTwoChoice == 0) {
            playerTwoChoiceString = "rock";
         } else if (playerTwoChoice == 1) {
            playerTwoChoiceString = "paper";
         } else {
            playerTwoChoiceString = "scissors";
         }
      
         int roundResult = scoring(playerOneChoice, playerTwoChoice);                                                                                                       // A method scores the round.
      

      
         switch (roundResult) {                                                                                                                                             // Based on that method's result, the round ends in a tie (not counted), a player one W, or a player two W.
            case 0:
               System.out.println("\nTie! Nobody wins this round. Both players chose " + playerOneChoiceString + ".");
               System.out.println("This round will not count as part of the best-of-three. Keep playing!");
               break;
            
            case 1:
               System.out.println("\n" + playerOneName + " wins this round!");
               System.out.println(playerOneName + " selected " + playerOneChoiceString + ", while " + playerTwoName + " selected " + playerTwoChoiceString + ".");
               playerOneWins++;                                                                                                                                             // Wins are tallied.
               break;
                     
            case 2:
               System.out.println("\n" + playerTwoName + " wins this round!");
               System.out.println(playerTwoName + " selected " + playerTwoChoiceString + ", while " + playerOneName + " selected " + playerOneChoiceString + ".");
               playerTwoWins++;
               break;
         
         }
      
      }
      
      if (playerOneWins == 2) {                                                                                                                                             // When the while loop ends, the winner is determined by win count.
         System.out.println("\n\nYour game winner is " + playerOneName + "!!!");                                                                                            // Somebody must have two wins because the loop ended.
         setPlayerWins(playerOneIndex, getPlayerWins(playerOneIndex) + 1);                                                                                                  // Adding to the win count for statistics.
         
      } else if (playerTwoWins == 2) {
         System.out.println("\n\nYour game winner is " + playerTwoName + "!!!");
         setPlayerWins(playerTwoIndex, getPlayerWins(playerTwoIndex) + 1);

      }
      
      System.out.println("\nI hope you had fun playing!:");
      System.out.println("Press 1 followed by enter to play again.");
      System.out.println("Otherwise, press any other key followed by enter to return to the mode's menu.");                                                                 // Post-game message
      
      String pressToReturn = kb.next();
      
      if (pressToReturn.equals("1")) {                                                                                                                                      // Any input works; no need for error handling.
         playHumanVersusHuman();
      } else {
         runHumanVersusHuman();
      }
      
   }
   
   
   
   
   
   // The scoring method takes in the players' choices and scores the round based off of them. The result is returned as an int.
   public int scoring(int playerOneChoice, int playerTwoChoice) {
      
      int winner = -1;
      if (playerOneChoice == playerTwoChoice) {                                                                                                                             // If the scores are the same, score the round as a tie (0).
         return 0;
      } 
      
      if (playerOneChoice == 0) {                                                                                                                                           // winner = 1 means player 1 won, while winner = 2 means player two won.
         if (playerTwoChoice == 1) {
            winner = 2;                                                                                                                                                     // The logic for the winner selection comes from Rock Paper Scissors rules.
         } else {                                                                                                                                                           // As it has always been for this program, 0 = rock, 1 = paper, and 2 = scissors.
            winner = 1;
         }
      
      } else if (playerOneChoice == 1) {
         if (playerTwoChoice == 0) {
            winner = 1;
         } else {
            winner = 2;
         }
         
      } else {
         if (playerTwoChoice == 0) {
            winner = 2;
         } else {
            winner = 1;
         }
      
      }
      
      return winner;
            
   }
   
   
   
   
   
   // The displayHumanVersusHumanInstructions() method shows the instructions for Human Versus Human.
   public void displayHumanVersusHumanInstructions() {
      System.out.println("\nWelcome to Rock Paper Scissors: Human Versus Human!\n");
      System.out.println("[1]: The game will first ask both players to select a player.");
      System.out.println("     You can either make your own player or select one from the database (if applicable).\n");
      System.out.println("[2]: Player One goes first.");
      System.out.println("     Player One types in a number (0 for Rock, 1 for Paper, 2 for Scissors).\n");
      System.out.println("[3]: Player Two goes next.");
      System.out.println("     Player Two types in a number (0 for Rock, 1 for Paper, 2 for Scissors).");
      System.out.println("     Please note that Player One's response will be hidden from Player Two.\n");
      System.out.println("[4]: The winner of the round will be revealed. The game proceeds to the next round (if applicable)");
      System.out.println("     Repeat steps 2 and 3 until a player has won two rounds. This is a best-of-three game.");
      System.out.println("     Ties will not be scored and thus will not count as part of the best-of-three.\n");
      System.out.println("[5]: The game will announce the game's overall winner.");
      System.out.println("     You can either play again or return to the main menu.\n\n");
      System.out.println("Press any key followed by enter to return to this mode's menu.\n");
      
      String pressToReturn = kb.next();                                                                                                                                     // Once a String is taken, the user immediately returns to the mode menu.
      runHumanVersusHuman();
      
   }
   
   
   
   
   
   // The runHumanVersusComputer() method runs the Human Versus Computer menu, allowing users to play Human Versus Human.
   public void runHumanVersusComputer() {
      System.out.println("\nWelcome to Human Versus Computer!");
      System.out.println("Proceed by typing the number of the option you wish to proceed to, then press enter.");
      System.out.println("[1]: Play Human Versus Computer");
      System.out.println("[2]: View Instructions");
      System.out.println("[3]: Return to Main Menu\n");
      
      
      int menuChoice = 0;
      
      while (menuChoice < 1 || menuChoice > 3) {                                                                                                                            // Error handling for InputMismatchException and "out-of-bounds" inputs                                                                                                                 
         try {                                                                                                                                                          
            menuChoice = kb.nextInt();
            kb.nextLine();
            
            if (menuChoice > 3) {
               System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");                                                 
            }
            
         } catch (Exception e) {
            System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");                                                    
            kb.nextLine();                                                                                                                                                  
         }
      }
      
      
      switch (menuChoice) {                                                                                                                                                 // Switch statement determines subsequent actions according to user choice.
         case 1:
            playHumanVersusComputer();
            break;
            
         case 2:
            displayHumanVersusComputerInstructions();
            break;
            
         case 3:
            run();
            break;
      }
   
   }
   
   
   
   
   
   // The playHumanVersusComputer() method runs the Human Versus Computer edition of Rock Paper Scissors.
   public void playHumanVersusComputer() {
      System.out.println("\nLet's Play!");                                                                                                                                  // The player gets to choose their character.
      System.out.println("Player One: Select a character.\n");
      System.out.println("Proceed by typing the number of the option you wish to proceed to, then press enter.\n");
      System.out.println("[0]: Create a New Character");
      
      int playerSelectionLimit = 0;
      
      for (int i = 1; i < 100; i++) {                                                                                                                                       // It's the same process compared to the Human Versus Human character selection.
         if (getPlayerName(i) != null) {
            System.out.println("[" + i + "]: " + getPlayerName(i));
            playerSelectionLimit = i;
         }
      }
      
      System.out.println("");
      
      int playerChoice = -1;
      int playerIndex = -1;
      
      while (playerChoice < 0 || playerChoice > playerSelectionLimit) {
         try {
         
            playerChoice = kb.nextInt();
            kb.nextLine();
            
            if (playerChoice > playerSelectionLimit) {
               System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
            }
         
         } catch (Exception e) {
            System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
            kb.nextLine();
         }
      }
      
      String playerName = "";
      
      if (playerChoice == 0) {
         System.out.println("\nChoose a name!");
         playerName = kb.nextLine();
         
         for (int i = 1; i < 100; i++) {
            if (getPlayerName(i) == null) {
               setPlayerName(i, playerName);
               playerIndex = i;
               break;
            }
         }
      } else {
         playerName = getPlayerName(playerChoice);
         playerIndex = playerChoice;
      }
      
      System.out.println("\nWelcome to the game, " + playerName + "!\n");
      
      System.out.println("\nYou will be playing against our computer, Hamilton.");                                                                                          // Refers to Lewis Hamilton.
      System.out.println("Hamilton can either play nice or mean.");
      System.out.println("If you want Hamilton to play nice, he will play a fair game.");
      System.out.println("If you want Hamilton to play mean, he will become so intelligent that he almost always beats you.");
      System.out.println("Do you want Hamilton to play nice or mean?");
      System.out.println("Proceed by typing the number of the option you wish to proceed to, then press enter.");
      System.out.println("[1]: Nice");
      System.out.println("[2]: Mean\n");
      
      int hamiltonChoice = 0;
      
      while (hamiltonChoice < 1 || hamiltonChoice > 2) {                                                                                                                    // Error handling for InputMismatchException and "out-of-bounds" input                                                                                                                 
         try {                                                                                                                                                          
            hamiltonChoice = kb.nextInt();
            kb.nextLine();
            
            if (hamiltonChoice > 2) {
               System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");                                                 
            }
            
         } catch (Exception e) {
            System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");                                                    
            kb.nextLine();                                                                                                                                                  
         }
      }
      
      boolean isHamiltonMean = false;                                                                                                                                       // Depending on the user's selection, isHamiltonMean will be true or false.
      
      if (hamiltonChoice == 1) {
         System.out.println("\nGreat! Hamilton will play nice!");
         
      } else {
         System.out.println("\nGreat! Hamilton will play mean!");
         isHamiltonMean = true;
         
      }
      
      
      
      int playerOneWins = 0;
      int hamiltonWins = 0;
      
      while (playerOneWins < 2 && hamiltonWins < 2) {                                                                                                                       // The game goes on until either Hamilton or the player has two wins.
      
         System.out.println("\n" + playerName + ", choose an option.");
         System.out.println("Type in 0 for Rock, 1 for Paper, and 2 for Scissors. Press enter when you have confirmed your choice.");
         System.out.println("Rock, Paper, Scissors, Shoot!\n");                                                                                                             // Player one selects his option - same process compared to the Human versus Human game.
      
         int playerGameChoice = -1;
      
         while (playerGameChoice < 0 || playerGameChoice > 2) {
            try {
            
               playerGameChoice = kb.nextInt();
               kb.nextLine();
            
               if (playerGameChoice > 2) {
                  System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
               }
            
            } catch (Exception e) {
               System.out.println("\nInvalid Input: Please type in a number that corresponds with an option on the menu.");
               kb.nextLine();
            }
         }
         
         int hamiltonGameChoice = -1;
         System.out.println("\nHamilton is choosing....");
         
         hamiltonGameChoice = chooseHamiltonNumber(playerGameChoice, isHamiltonMean);                                                                                       // Hamilton's choice depends on whether he is mean or not. If he is mean, the player's choice has some input.
         
         String playerGameChoiceString = "";                                                                                                                                // Like the Human Versus Human method, this translates the numerical option into string for the end-of-round text.
         String hamiltonGameChoiceString = "";
      
         if (playerGameChoice == 0) {
            playerGameChoiceString = "rock";
         } else if (playerGameChoice == 1) {
            playerGameChoiceString = "paper";
         } else {
            playerGameChoiceString = "scissors";
         }
      
         if (hamiltonGameChoice == 0) {
            hamiltonGameChoiceString = "rock";
         } else if (hamiltonGameChoice == 1) {
            hamiltonGameChoiceString = "paper";
         } else {
            hamiltonGameChoiceString = "scissors";
         }
         
         try {                                                                                                                                                              // Thread.sleep gives some extra anticipation for Hamilton's choice.
            Thread.sleep(2000);
            System.out.println("\nHe seems ready...");
            Thread.sleep(1000);
            System.out.println("\nHamilton chooses " + hamiltonGameChoiceString + "!");                                                                                       // Having his String option present in this sequence is why the Thread.sleep location seems "out-of-order."
            Thread.sleep(750);
         } catch (Exception e) {
            continue;
         }
         
         int roundResult = scoring(playerGameChoice, hamiltonGameChoice);                                                                                                   // Scoring the round
      

      
         switch (roundResult) {
            case 0:
               System.out.println("\nTie! Nobody wins this round. Both players chose " + playerGameChoiceString + ".");                                                     // End-of-round text is contingent on the end result.
               System.out.println("This round will not count as part of the best-of-three. Keep playing!");
               break;
            
            case 1:
               System.out.println("\n" + playerName + " wins this round!");
               System.out.println(playerName + " selected " + playerGameChoiceString + ", while Hamilton selected " + hamiltonGameChoiceString + ".");
               playerOneWins++;
               break;
                     
            case 2:
               System.out.println("\nHamilton wins this round!");
               System.out.println("Hamilton selected " + hamiltonGameChoiceString + ", while " + playerName + " selected " + playerGameChoiceString + ".");
               hamiltonWins++;
               break;
         
         }
          
      }
      
      if (playerOneWins == 2) {
         System.out.println("\n\nYour game winner is " + playerName + "!!!");                                                                                               // Depending on who has more wins, the end-of-game result is displayed with the winner.
         setPlayerWins(playerIndex, getPlayerWins(playerIndex) + 1);
         
      } else if (hamiltonWins == 2) {
         System.out.println("\n\nYour game winner is Hamilton!!!");
      }
      
      System.out.println("\nI hope you had fun playing!:");
      System.out.println("Press 1 followed by enter to play again.");
      System.out.println("Otherwise, press any other key followed by enter to return to the mode's menu.");
      
      String pressToReturn = kb.next();
      
      if (pressToReturn.equals("1")) {
         playHumanVersusComputer();
      } else {
         runHumanVersusComputer();
      }
   }
   
   
   
   
   
   // The chooseHamiltonNumber method takes in the player choice, which, if he is mean, will have some input in his selection.
   // The method returns 0, 1, or 2 (rock, paper, or scissors - Hamilton's option).
   public int chooseHamiltonNumber(int playerChoice, boolean isMean) {
      int result = 0;
      
      if (isMean) {
         if (Math.random()*10 > 8) {                                                                                                                                        // If Hamilton is mean, there is a high chance he'll choose the response that beats the user's response.
            result = (int)(Math.random()*3);                                                                                                                                // There is a small chance he will choose a random option, though.
         } else {
         
            if (playerChoice == 0) {
               result = 1;
            } else if (playerChoice == 1) {
               result = 2;
            } else {
               result = 0;
            }
         
         }
         
      } else {
         result = (int)(Math.random()*3);                                                                                                                                   // If Hamilton is not mean, he will always play a fair/random option.
      }
      
      return result;
   }
   
   
   
   
   
   // The displayHumanVersusComputerInstructions() method displays the instructions for Human Versus Computer.
   public void displayHumanVersusComputerInstructions() {
      System.out.println("\nWelcome to Rock Paper Scissors: Human Versus Computer!\n");
      System.out.println("[1]: The game will first ask you to select a player.");
      System.out.println("     You can either make your own player or select one from the database (if applicable).\n");
      System.out.println("[2]: You will go first.");
      System.out.println("     Type in a number (0 for Rock, 1 for Paper, 2 for Scissors).\n");
      System.out.println("[3]: The computer will go immediately, and the winner of the round will be revealed.");
      System.out.println("     The game proceeds to the next round (if applicable).");
      System.out.println("     Repeat step 2 until either you or the computer has won two rounds. This is a best-of-three game.");
      System.out.println("     Ties will not be scored and thus will not count as part of the best-of-three.\n");
      System.out.println("[4]: The game will announce the game's overall winner.");
      System.out.println("     You can either play again or return to the main menu.\n\n");
      System.out.println("Press any key followed by enter to return to this mode's menu.\n");
      
      String pressToReturn = kb.next();                                                                                                                                     // Entering anything takes you back to the main menu.
      runHumanVersusComputer();
      
   }
   
   
   
   
   
   // The displayStatistics() method displays user statistics.
   public void displayStatistics() {
      System.out.println("\nSTATISTICS:\n");
      
      boolean noStatistics = true;
      
      for (int i = 0; i < 100; i++) {                                                                                                                                       // The method checks the database for any existing users and adds their data to the database.
         if (getPlayerName(i) != null) {
            noStatistics = false;
            System.out.println(getPlayerName(i) + ": " + getPlayerWins(i) + " Win(s)");
         }
      }
      
      System.out.println("");
      
      if (noStatistics) {                                                                                                                                                   // If there are no statistics, a message displays instead.
         System.out.println("There are no statistics yet! Play some games to get statistics!\n");
      }
      
      System.out.println("Press any key followed by enter to return to the menu.\n");
      
      String pressToReturn = kb.next();                                                                                                                                     // Once a String is entered, players return to the main menu.
      System.out.println("");
      run();
      


   }
   
   
   
   
   
   // GETTERS AND SETTERS
   public int getPlayerWins(int index) {
      return playerWins[index];
   }
   
   
   public String getPlayerName(int index) {
      return playerNames[index];
   }
   
   
   public void setPlayerWins(int index, int wins) {                                                                                                                         // Since these are arrays, getters and setters depend on the index of the stored information you need.
      playerWins[index] = wins;
   }
   
   
   public void setPlayerName(int index, String name) {
      playerNames[index] = name;
   }
   
}