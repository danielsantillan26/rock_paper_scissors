/*
Name: Daniel Santillan
Class: AP CS A
Date: 11/29/2023
Program Description: The Main class runs the Rock Paper Scissors Game.
*/

public class Main {

   public static void main(String[] args) {
   
      RockPaperScissors game = new RockPaperScissors();                             // This creates a RockPaperScissors object and invokes its run method, which starts the entire game.
      game.run();
   
   }

}